describe('Test extension', () => {

    it('This is a dummy test', () => {
        expect(true).to.be.true;
    });
});